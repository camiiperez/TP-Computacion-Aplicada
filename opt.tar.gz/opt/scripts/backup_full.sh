#!/bin/bash
# ------------------------------------------------------------------
# backup_full.sh - Script de backup completo
# Trabajo Práctico Integrador - Computación Aplicada (UP)
#
# Uso:   backup_full.sh <origen> <destino>
#        backup_full.sh -help
# Ej.:   backup_full.sh /var/log /backup_dir
#        -> genera /backup_dir/log_bkp_AAAAMMDD.tar.gz
# ------------------------------------------------------------------

# Función que muestra la ayuda
mostrar_ayuda() {
    echo "Uso: $0 <origen> <destino>"
    echo ""
    echo "  <origen>   Directorio que se quiere respaldar (ej: /var/log)"
    echo "  <destino>  Directorio donde se guarda el backup (ej: /backup_dir)"
    echo ""
    echo "El archivo generado se llama <nombre>_bkp_AAAAMMDD.tar.gz"
    echo "Ejemplo: $0 /var/log /backup_dir  ->  /backup_dir/log_bkp_$(date +%Y%m%d).tar.gz"
    echo ""
    echo "Opciones:"
    echo "  -help      Muestra esta ayuda"
}

# 1) Opción de ayuda
if [ "$1" = "-help" ] || [ "$1" = "--help" ] || [ "$1" = "-h" ]; then
    mostrar_ayuda
    exit 0
fi

# 2) Validar cantidad de argumentos
if [ $# -ne 2 ]; then
    echo "Error: se necesitan 2 argumentos (origen y destino)."
    mostrar_ayuda
    exit 1
fi

# 3) Guardar los argumentos sacando la "/" final si la tienen
ORIGEN="${1%/}"
DESTINO="${2%/}"

# 4) Validar que el origen exista y sea un directorio
if [ ! -d "$ORIGEN" ]; then
    echo "Error: el origen '$ORIGEN' no existe o no es un directorio."
    exit 2
fi

# 5) Validar que el destino exista y sea un directorio
if [ ! -d "$DESTINO" ]; then
    echo "Error: el destino '$DESTINO' no existe o no es un directorio."
    exit 2
fi

# 6) Validar que los sistemas de archivos de origen y destino estén disponibles (montados)
if ! findmnt -T "$ORIGEN" > /dev/null 2>&1; then
    echo "Error: el sistema de archivos del origen '$ORIGEN' no está disponible."
    exit 3
fi

if ! findmnt -T "$DESTINO" > /dev/null 2>&1; then
    echo "Error: el sistema de archivos del destino '$DESTINO' no está disponible."
    exit 3
fi

# 7) Si el destino es /backup_dir, comprobar que la partición esté realmente montada
#    (si no lo está, el backup se guardaría en el disco principal por error)
if [[ "$DESTINO" == /backup_dir* ]] && ! mountpoint -q /backup_dir; then
    echo "Error: la partición de /backup_dir no está montada."
    exit 3
fi

# 8) Validar que se pueda escribir en el destino
if [ ! -w "$DESTINO" ]; then
    echo "Error: no hay permiso de escritura en '$DESTINO'."
    exit 4
fi

# 9) Armar el nombre del archivo: <nombre>_bkp_AAAAMMDD.tar.gz
NOMBRE=$(basename "$ORIGEN")          # /var/log -> log
FECHA=$(date +%Y%m%d)                 # formato ANSI: 20261111
ARCHIVO="$DESTINO/${NOMBRE}_bkp_${FECHA}.tar.gz"

# 10) Crear el backup comprimido
echo "Iniciando backup de '$ORIGEN' en '$ARCHIVO' ..."
if tar -czf "$ARCHIVO" -C "$(dirname "$ORIGEN")" "$NOMBRE"; then
    echo "Backup creado correctamente: $ARCHIVO"
    exit 0
else
    echo "Error: falló la creación del backup."
    exit 5
fi
