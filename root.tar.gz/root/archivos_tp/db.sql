CREATE USER IF NOT EXISTS 'computacion'@'localhost' IDENTIFIED BY 'aplicada';
CREATE USER IF NOT EXISTS 'computacion'@'127.0.0.1' IDENTIFIED BY 'aplicada';
GRANT ALL PRIVILEGES ON ca_viernes.* TO 'computacion'@'localhost';
GRANT ALL PRIVILEGES ON ca_viernes.* TO 'computacion'@'127.0.0.1';
FLUSH PRIVILEGES;

USE ca_viernes;

DROP TABLE IF EXISTS videos;

CREATE TABLE videos (
    id INT AUTO_INCREMENT PRIMARY KEY,
    banda VARCHAR(255) NOT NULL,
    tema VARCHAR(255) NOT NULL,
    archivo_mp4 VARCHAR(255) NOT NULL,
    youtube_id VARCHAR(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO videos (banda, tema, archivo_mp4, youtube_id) VALUES
('CSNZ LATINO', 'Linux: La película ♦ ', 'linux.mp4', 'G13a9fAJ40Q'),
('Ricky Martin', '#! ♦ ', 'ricky_martin.mp4', 'q51DG9Wmc_4'),
('Daft Punk', 'Give Life Back to Music ♦ ', 'daft_punk.mp4', 'IluRBvnyMOY'),
('The Blaze', 'SHE ♦ ', 'the_blaze.mp4', 'ygi2H9W6VRQ'),
('Guasones', 'Pasan las horas ♦ ', 'guasones.mp4', 'HUQNgPbtNhw'),
('Dream Theater', 'Octavarium ♦ ', 'dream_theater.mp4', 'XYV8Zt2k0RQ'),
('Soda Stereo', 'Persiana Americana ♦ ', 'soda_stereo.mp4', '7ZdLVrui8tM'),
('Benson Boone', 'There She Goes ♦ ', 'benson_boone.mp4', 'mWDwNydOlho'),
('Alice In Chains', 'Man in the Box ♦ ', 'alice_in_chains.mp4', 'TAqZb52sgpU'),
('Tan Bionica', 'La Melodía de Dios ♦ ', 'tan_bionica.mp4', '_8LHnLFwrtA'),
('Post Malone', 'Wow. ♦ ', 'post_malone.mp4', 'NA4uIFbVCPM'),
('The Beatles', 'Good Night ♦ ', 'beatles.mp4', 'Qp_djiUQ2Cw');