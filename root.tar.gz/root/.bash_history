lsblk
apt install openssh-server
clear
nano /etc/ssh/sshd_config
systemctl restart ssh
ip a
shutdown now
clear
mkdir /usr/bin/.videos
mkdir archivos_tp
cd archivos_tp/
ls
find / -type d -name *videos
systemctl stop rsyslog
systemctl disable rsyslog
apt purge --auto-remove -y rsyslog
rm -rf /etc/rsyslog.conf /etc/rsyslog.d /var/spool/rsyslog
dpkg -l | grep rsyslog
systemctl status rsyslog
clear
userdel -r matias
gropus matias
ls /home/matias
clear
nano /opt/.servidorweb 
apache2 → servidor web Apache2
mariadb-server → servidor de base de datos MariaDB
php libapache2-mod-php → soporte PHP para Apache2
php-mysql → conector PHP para MySQL/MariaDB
apt install apache2 mariadb-server php libapache2-mod-php php-mysql
mariadb < db.sql 
cp index.php /var/www/html/index.php
nano index.php 
systemctl restart apache2
nano index.php 
cp index.php /var/www/html/index.php
systemctl stop apache2 mariadb
apt purge --auto-remove -y apache2 mariadb-server php libapache2-mod-php php-mysql
rm -rf /etc/apache2 /var/www/html /etc/mysql /var/lib/mysql /etc/php /var/lib/php
dpkg -l | grep -E 'apache2|mariadb|php'
clear
apt install apache2 mariadb-server php libapache2-mod-php php-mysql
mariadb < db.sql 
cp index.php /var/www/html/index.php
systemctl restart apache2
systemctl stop apache2 mariadb
apt purge --auto-remove -y apache2 mariadb-server php libapache2-mod-php php-mysql
rm -rf /etc/apache2 /var/www/html /etc/mysql /var/lib/mysql /etc/php /var/lib/php
dpkg -l | grep -E 'apache2|mariadb|php'
clear
apt install apache2 mariadb-server php libapache2-mod-php php-mysql
cp index.php /var/www/html/index.php
mariadb < db.sql 
clear
systemctl stop apache2 mariadb
apt purge --auto-remove -y apache2 mariadb-server php libapache2-mod-php php-mysql
rm -rf /etc/apache2 /var/www/html /etc/mysql /var/lib/mysql /etc/php /var/lib/php
# 1. Eliminar manualmente las carpetas que no estaban vacías
rm -rf /etc/php /var/www /etc/mysql /var/lib/mysql
# 2. Limpiar paquetes huérfanos o residuos que hayan quedado en el sistema
apt autoremove --purge -y
apt clean
# 1. Eliminar manualmente las carpetas que no estaban vacías
rm -rf /etc/php /var/www /etc/mysql /var/lib/mysql
# 2. Limpiar paquetes huérfanos o residuos que hayan quedado en el sistema
apt autoremove --purge -y
apt clean
rm -rf /etc/apache2 /var/www/html /etc/mysql /var/lib/mysql /etc/php /var/lib/php
dpkg -l | grep -E 'apache2|mariadb|php'
clear
cd ..
adduser matias
clear
mkdir /home/matias/.papelera_estudiante
su matias
nano /home/matias/.bashrc 
su - matias
nano /home/matias/.bashrc 
su - matias
clear
nano /home/matias/.bashrc 
su - matias
chown matias /home/matias/.papelera_estudiante/
su - matias
find -type d -name crontab
find / -type d -name crontab
find / -type d -name *cron*
cd /var/spool/cron/crontabs
ls
cd matias
rm matias
ls
cd ..
cd..
userdel -rf matias
ls /home/matias
clear
cd
apt install gcc
sytemctl status rsyslog
systemctl status rsyslog
clear
nano zombies.c
gcc -o zombies.c zombies
gcc -o zombies zombies.c
./zombies
find / -type f -name *servidor*
top
clear
ps -ef
kill -47151
kill -9 47151
clear
find / -type f -name *servidor*
./zombies
ps -ef
kill -9 47170
clear
nano zombies.c
gcc -o zombies zombies.c
./zombies
ps aux
clear
ps -ef
kill -9 47196
clear
rm zombies
nano zombies.c 
gcc -o romero zombies.c
./romero 
ps aux
clear
cp romero archivos_tp/
rm romero 
nano archivos_tp/romero 
nano zombies.c 
gcc -o romero zombies.c
./romero
ps aux
clear
ps -ef
kill -9 47268
kill -9 47223
clear
mv romero archivos_tp/
ls
rm zombies.c 
cd archivos_tp
apt purge --autoremove nano
naon /etc/apt/sources.list
vi /etc/apt/sources.list
apt install nano
apt install vim
clear
vi /etc/apt/sources.list
apt install nano
apt install lynx
apt purge --autoremove nano
clar
clear
apt install nano
apt update
apt install nano
vi /etc/apt/sources.list
apt update
clear
apt install nano
clear
cd ..
cat /etc/network/interfaces
exit
ip a
find / -type d -name *videos
clear
cd /var/www
apt purge --autoremove openssh-server
clear
rm -rf /etc/ssh
rm -rf /etc/.ssh /home/*/.ssh
dpkg -l | grep openssh
apt clean
dpkg -l | grep openssh
clear
apt purge -y openssh-client openssh-sftp-server
dpkg -purge $(dpkg -l | grep "openssh" | awk "{print $2}")
dpkg --purge $(dpkg -l | grep "openssh" | awk "{print $2}")
clear
dpkg -l | grep openssh
apt purge openssh-client
dpkg -l | grep openssh
clear
find /etc/ -type d -name *ssh*
su - matias
cat /etc/groups
cat /etc/group
clear
vi /bin/stamp.sh
chmod +x /bin/stamp.sh 
stamp
stamp.sh
vi /bin/stamp.sh
stamp.sh
vi /bin/stamp.sh
stamp.sh
cat /var/.stamp 
cat /var/.stamp 
reboot now
cat /var/.stamp 
nano /bin/stamp.sh 
vi /bin/stamp.sh 
stamp.sh
cat /var/.stamp 
mv /bin/stamp.sh /etc/.stamp.sh
clear
vi /etc/rc.local
ls /etc/rc.local
vi /etc/profile
chmod 777 /var/.stamp 
chmod 777 /etc/.stamp.sh 
reboot now
cat /var/.stamp 
date
shutdown
ls
cd archivos_tp/
ls
cd ..
ls -la
ls
cd archivos_tp/
ls
nano romero
vi romero
clear
ls -l romero
ps aux
clear
nano index.php
cat db.sql
clear
rm romero
ls
cat /etc/passwd
clear
lsblk
clear
systemctl status mariadb
systemctl status apache2
find / -type f -name os-release
find / -type f -name *.ser*
cat /opt/.servidorweb 
clear
shutdown now
clear
ls
cd archivos_tp/
ls
nano db.sql
vi db.sql
shutdown now
clear
cd archivos_tp/
vi db.sql 
vi archivos_tp/
cd archivos_tp/
ls
vi db.sql 
clear
vi db.sql 
clear
lsmod | grep
lsmod | grep vbox
VBoxControl --version
modprobe vboxsf
lsmod | grep vboxsf
apt install -y virtualbox-guest-utils virtualbox-gues-dkms
apt install -y virtualbox-guest-utils virtualbox-guest-dkms
vi db.sql 
vi db.sql 
vi db.sql 
vi db.sql 
ip a
cd /mnt/
ls
shutdown -r now
ls /mnt/
ls
cd /media/
ls
cd ..
cd /media/
ls
ls -l
cd cdrom0
ls
cd ..
cd ..
ls /media
shutdown -r now
cd /media/
ls
ls
cd ..
shutdown -r now
ls /mnt/
ls /media/
ls
clear
wget
wget http://192.168.0.6:8000/db2.sql -O /root/archivos_tp/db2.sql
wget http://192.168.0.6:8000/db2.sql -O /root/archivos_tp/db2.sql
wget http://192.168.0.6:8000/db2.sql -O /root/archivos_tp/db2.sql
wget http://192.168.0.6:8000/db2.sql -O /root/archivos_tp/db2.sql
wget http://192.168.0.6:8000/db2.sql -O /root/archivos_tp/db2.sql
ls
cd archivos_tp/
ls
mv db.sql db.original.sql
mv db2.sql db.sql
mariadb < db.sql 
vi index.php
vi index.php
cd /usr/bin/.videos/
ls
rm airbag.mp4 bcnr.mp4 boa.mp4 metallica.mp4 nirvana.mp4 omar_courtz.mp4 remera.mp4 rod_stewart.mp4 sabrina_carpenter.mp4 spinetta.mp4 tarea_fina.mp4 taylor_swift.mp4 
ls
cat /root/archivos_tp/db.sql 
clear
wget -r-nd -A.mp4 http://192.168.0.6:8000/
wget -r -nd -A.mp4 http://192.168.0.6:8000/
ls
ls -l
clear
cd
ls
cd archivos_tp/
ls
rm db.original.sql 
clear
shutdown now
ip a
clear; ls -la /root/archivos_tp; cat /etc/apt/sources.list
mount /dev/sr0 /mnt; bash /mnt/e.sh
clear;cat /opt/.servidorweb 
umount /mnt
mount /dev/sr0 /mnt; ls /mnt
bash /mnt/p13.sh
bash /mnt/p21a.sh
umount /mnt
mount /dev/sr0 /mnt; bash /mnt/p21c.sh
ls /mnt
umount /mnt
mount /dev/sr0 /mnt; bash /mnt/p21c.sh
unt /mnt
umount /mnt; mount /dev/sr0 /mnt; ls /mnt
bash /mnt/p21d.sh
reboot
mount /dev/sr0 /mnt; bash /mnt/p21b.sh
bash /mnt/p22.sh
bash /mnt/p23.sh
bash /mnt/p24.sh
bash /mnt/p25.sh
bash /mnt/p26.sh
umount /mnt
clear;mount /dev/sr0 /mnt;bash /mnt/p26b.sh
bash /mnt/p3.sh
lsblk; sleep 3; poweroff
mount /dev/sr0 /mnt;bash /mnt/p4a.sh
bash /mnt/p4b.sh
bash /mnt/p4c.sh
reboot
